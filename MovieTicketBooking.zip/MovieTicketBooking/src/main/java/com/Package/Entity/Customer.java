package com.Package.Entity;

public class Customer {

}
