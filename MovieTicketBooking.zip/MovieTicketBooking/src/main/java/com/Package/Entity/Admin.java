package com.Package.Entity;

public class Admin {

}
